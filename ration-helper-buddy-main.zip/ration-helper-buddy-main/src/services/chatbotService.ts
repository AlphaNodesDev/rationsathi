import { getDemoRation, RationQuota } from './rationService';

export interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

// Simple rule-based NLP for ration queries
export const processQuery = (query: string, cardType: string): { answer: string; quota: RationQuota } => {
  const q = query.toLowerCase();
  const quota = getDemoRation(cardType);

  // Check for specific item queries
  if (q.includes('rice') || q.includes('ari') || q.includes('chawal')) {
    return {
      answer: `You have ${quota.rice}kg of rice this month at ₹${quota.ricePrice}/kg.`,
      quota,
    };
  }
  if (q.includes('wheat') || q.includes('gothambu') || q.includes('gehu') || q.includes('atta')) {
    return {
      answer: `You have ${quota.wheat}kg of wheat this month at ₹${quota.wheatPrice}/kg.`,
      quota,
    };
  }
  if (q.includes('kerosene') || q.includes('manne') || q.includes('mitti')) {
    return {
      answer: `You have ${quota.kerosene}L of kerosene this month at ₹${quota.kerosenePrice}/L.`,
      quota,
    };
  }
  if (q.includes('sugar') || q.includes('panju saara') || q.includes('cheeni') || q.includes('shakkar')) {
    return {
      answer: `You have ${quota.sugar}kg of sugar this month at ₹${quota.sugarPrice}/kg.`,
      quota,
    };
  }
  if (q.includes('price') || q.includes('cost') || q.includes('vila') || q.includes('kitna')) {
    const total = quota.rice * quota.ricePrice + quota.wheat * quota.wheatPrice + quota.kerosene * quota.kerosenePrice + quota.sugar * quota.sugarPrice;
    return {
      answer: `Your total ration cost this month is ₹${total.toFixed(2)}.`,
      quota,
    };
  }

  // Default: show all
  const total = quota.rice * quota.ricePrice + quota.wheat * quota.wheatPrice + quota.kerosene * quota.kerosenePrice + quota.sugar * quota.sugarPrice;
  return {
    answer: `Your ${cardType} card quota this month:\n• Rice: ${quota.rice}kg (₹${quota.ricePrice}/kg)\n• Wheat: ${quota.wheat}kg (₹${quota.wheatPrice}/kg)\n• Kerosene: ${quota.kerosene}L (₹${quota.kerosenePrice}/L)\n• Sugar: ${quota.sugar}kg (₹${quota.sugarPrice}/kg)\n\nTotal: ₹${total.toFixed(2)}`,
    quota,
  };
};

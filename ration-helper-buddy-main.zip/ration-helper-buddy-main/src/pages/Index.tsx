// Update this page (the content is just a fallback if you fail to update the page)
import { Navigate } from 'react-router-dom';

const Index = () => <Navigate to="/dashboard" replace />;

export default Index;
